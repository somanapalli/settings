package com.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.dao.CustomerDao;
import com.spring.model.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	ApplicationContext context = new ClassPathXmlApplicationContext("spring_hibernate.xml");
    	CustomerDao custDao = (CustomerDao)context.getBean("custdao");
    	Customer customer = new Customer();
    	customer.setCno(100);
    	customer.setCname("ram");
    	customer.setAddress("hyd");
    	customer.setPhone(8500122392L);
    	custDao.save(customer);
    	
    }
}
