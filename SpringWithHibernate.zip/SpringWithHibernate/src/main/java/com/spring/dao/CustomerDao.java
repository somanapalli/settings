package com.spring.dao;



import com.spring.model.Customer;

public interface CustomerDao {
	
	public void save(Customer c);

}
