package com.spring.dao;

import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.spring.model.Customer;

@Repository("custdao")
public class CustomerDaoImpl implements CustomerDao {
	private HibernateTemplate hibernateTemplate;
	public CustomerDaoImpl() {}
	public void save(final Customer c) {
		
		/*
		 * hibernateTemplate.execute(new HibernateCallback() {
		 * 
		 * public Object doInHibernate(Session session) throws HibernateException {
		 * Integer i = (Integer)session.save(c); return i; } });
		 */	
		//short cut approach
		hibernateTemplate.save(c);

	}

}
