package com.spring.model;

import java.io.Serializable;

public class Customer implements Serializable {
	
	private int cno;
	private String cname;
	private String address;
	private long phone;
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public Customer(int cno, String cname, String address, long phone) {
		super();
		this.cno = cno;
		this.cname = cname;
		this.address = address;
		this.phone = phone;
	}
	public Customer()
	{
		
	}
	

}
